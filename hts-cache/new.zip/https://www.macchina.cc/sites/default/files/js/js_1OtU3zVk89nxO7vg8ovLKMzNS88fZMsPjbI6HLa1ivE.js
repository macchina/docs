jQuery(document).ready(function($){$("#block-multiblock-1").hide();$(".node-type-blog #node-comment-count").click(function(){$("#block-multiblock-1").slideToggle();$(this).toggleClass("closed")})});;
