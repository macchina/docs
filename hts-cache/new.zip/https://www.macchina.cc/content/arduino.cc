<!DOCTYPE html>
<html lang="en" dir="ltr"
  xmlns:content="http://purl.org/rss/1.0/modules/content/"
  xmlns:dc="http://purl.org/dc/terms/"
  xmlns:foaf="http://xmlns.com/foaf/0.1/"
  xmlns:og="http://ogp.me/ns#"
  xmlns:rdfs="http://www.w3.org/2000/01/rdf-schema#"
  xmlns:sioc="http://rdfs.org/sioc/ns#"
  xmlns:sioct="http://rdfs.org/sioc/types#"
  xmlns:skos="http://www.w3.org/2004/02/skos/core#"
  xmlns:xsd="http://www.w3.org/2001/XMLSchema#">
<head profile="http://www.w3.org/1999/xhtml/vocab">
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="shortcut icon" href="https://www.macchina.cc/sites/default/files/favicon1.png" type="image/png" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<meta name="MobileOptimized" content="width" />
<meta name="Generator" content="Drupal 7 (http://drupal.org)" />
<meta name="HandheldFriendly" content="true" />
  <title>Page not found | Macchina</title>
  <link type="text/css" rel="stylesheet" href="https://www.macchina.cc/sites/default/files/css/css_xE-rWrJf-fncB6ztZfd2huxqgxu4WO-qwma6Xer30m4.css" media="all" />
<link type="text/css" rel="stylesheet" href="https://www.macchina.cc/sites/default/files/css/css_ZjkPAxW5TUC6BgXDB8zdjy-DyQ9ndILNs9KumxTlpjM.css" media="all" />
<link type="text/css" rel="stylesheet" href="https://www.macchina.cc/sites/default/files/css/css_NdwwF6t6aglzfZPE3GdMuKDTx2iraepCt_wNWzz6UfA.css" media="all" />
<link type="text/css" rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" media="all" />
<link type="text/css" rel="stylesheet" href="https://www.macchina.cc/sites/default/files/css/css_s_tXQGFMqeCZV0ncp4HPPVFzGSa-0X70-QmJTLIbJoU.css" media="all" />

<!--[if (lt IE 9)]>
<link type="text/css" rel="stylesheet" href="https://www.macchina.cc/sites/all/themes/macchina_bb/css/ie8.css?ots7f8" media="all" />
<![endif]-->

    
  <!-- HTML5 element support for IE6-8 -->
  <!--[if lt IE 9]>
    <script src="//html5shiv.googlecode.com/svn/trunk/html5.js"></script>
  <![endif]-->
  <script type="text/javascript" src="https://www.macchina.cc/sites/default/files/js/js_g9KXZPmxgJ0pQYJeyxq_SiYSpL6WflD1eQ_kKEXvja4.js"></script>
<script type="text/javascript" src="https://www.macchina.cc/sites/default/files/js/js_1g9qr0dJ2DQpDdr8gYM584BidjryGgFlD0XAHs3iDzo.js"></script>
<script type="text/javascript" src="https://www.macchina.cc/sites/default/files/js/js_MznaG7R7Xjf_V3Kifs9y0mv5SlKgADRdZ_AHoPrTsJc.js"></script>
<script type="text/javascript" src="https://www.macchina.cc/sites/default/files/js/js_NtwpKAnSrErIcr0xxQI9COWpIAqvErPBpzFJO86eUtA.js"></script>
<script type="text/javascript">
<!--//--><![CDATA[//><!--
(function(i,s,o,g,r,a,m){i["GoogleAnalyticsObject"]=r;i[r]=i[r]||function(){(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)})(window,document,"script","//www.google-analytics.com/analytics.js","ga");ga("create", "UA-75126303-1", {"cookieDomain":"auto"});ga("set", "anonymizeIp", true);ga("set", "page", "/404.html?page=" + document.location.pathname + document.location.search + "&from=" + document.referrer);ga("send", "pageview");
//--><!]]>
</script>
<script type="text/javascript" src="//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
<script type="text/javascript">
<!--//--><![CDATA[//><!--
jQuery(document).ready(function($) { 
		$(window).scroll(function() {
			if($(this).scrollTop() != 0) {
				$("#toTop").fadeIn();	
			} else {
				$("#toTop").fadeOut();
			}
		});
		
		$("#toTop").click(function() {
			$("body,html").animate({scrollTop:0},800);
		});	
		
		});
//--><!]]>
</script>
<script type="text/javascript" src="https://www.macchina.cc/sites/default/files/js/js_1OtU3zVk89nxO7vg8ovLKMzNS88fZMsPjbI6HLa1ivE.js"></script>
<script type="text/javascript">
<!--//--><![CDATA[//><!--
jQuery.extend(Drupal.settings, {"basePath":"\/","pathPrefix":"","ajaxPageState":{"theme":"macchina_bb","theme_token":"_CcMzywstjTLdhWzL4jq8IFzYL_VEGRo0Llbj2DNqSw","js":{"sites\/default\/files\/minify\/jquery.1.4.4.min.js":1,"sites\/default\/files\/minify\/jquery.once.1.2.min.js":1,"sites\/default\/files\/minify\/drupal.min.js":1,"sites\/default\/files\/minify\/jquery.cookie.1.0.min.js":1,"sites\/default\/files\/minify\/collapsiblock.min.js":1,"sites\/default\/files\/minify\/googleanalytics.min.js":1,"0":1,"\/\/maxcdn.bootstrapcdn.com\/bootstrap\/3.2.0\/js\/bootstrap.min.js":1,"1":1,"sites\/default\/files\/minify\/script.min.js":1},"css":{"modules\/system\/system.base.css":1,"modules\/system\/system.menus.css":1,"modules\/system\/system.messages.css":1,"modules\/system\/system.theme.css":1,"sites\/all\/modules\/simplenews\/simplenews.css":1,"modules\/book\/book.css":1,"sites\/all\/modules\/collapsiblock\/collapsiblock.css":1,"modules\/comment\/comment.css":1,"modules\/field\/theme\/field.css":1,"sites\/all\/modules\/mollom\/mollom.css":1,"modules\/node\/node.css":1,"modules\/poll\/poll.css":1,"modules\/search\/search.css":1,"modules\/user\/user.css":1,"modules\/forum\/forum.css":1,"sites\/all\/modules\/views\/css\/views.css":1,"sites\/all\/modules\/ctools\/css\/ctools.css":1,"public:\/\/css\/menu_icons.css":1,"\/\/maxcdn.bootstrapcdn.com\/bootstrap\/3.2.0\/css\/bootstrap.min.css":1,"sites\/all\/themes\/macchina_bb\/css\/style.css":1,"sites\/all\/themes\/macchina_bb\/color\/colors.css":1,"sites\/all\/themes\/bootstrap_business\/css\/local.css":1,"sites\/all\/themes\/macchina_bb\/css\/macchina.css":1,"sites\/all\/themes\/macchina_bb\/css\/ie8.css":1}},"collapsiblock":{"blocks":{"block-commentsblock-comment-form-block":"1","block-multiblock-1":"1","block-block-3":"1","block-block-7":"1","block-block-6":"1","block-block-12":"1","block-system-navigation":"1","block-nodeblock-103":"1","block-nodeblock-104":"1","block-nodeblock-105":"1","block-nodeblock-146":"1","block-nodeblock-153":"1","block-nodeblock-154":"1","block-commerce-cart-cart":"1","block-menu-menu-shop":"1","block-nodeblock-98":"1","block-forum-active":"1","block-nodeblock-95":"1","block-block-20":"1","block-block-21":"1","block-block-22":"1","block-menu-menu-top-user-menu-3":"1","block-book-menus-navigation":"2","block-multiblock-2":"3","block-discourse-sso-discourse-link":"1","block-nodeblock-212":"1","block-block-1":"1","block-nodeblock-216":"1","block-block-23":"1","block-nodeblock-217":"1","block-nodeblock-87":"1","block-nodeblock-219":"1","block-block-24":"1","block-menu-menu-learn":"2","block-menu-book-toc-6":"2","block-menu-menu-guide-menu":"2"},"default_state":"2","slide_type":"1","slide_speed":"200","block_title":":header:first","block":"div.block","block_content":"div.content"},"googleanalytics":{"trackOutbound":1,"trackMailto":1,"trackDownload":1,"trackDownloadExtensions":"7z|aac|arc|arj|asf|asx|avi|bin|csv|doc(x|m)?|dot(x|m)?|exe|flv|gif|gz|gzip|hqx|jar|jpe?g|js|mp(2|3|4|e?g)|mov(ie)?|msi|msp|pdf|phps|png|ppt(x|m)?|pot(x|m)?|pps(x|m)?|ppam|sld(x|m)?|thmx|qtm?|ra(m|r)?|sea|sit|tar|tgz|torrent|txt|wav|wma|wmv|wpd|xls(x|m|b)?|xlt(x|m)|xlam|xml|z|zip"}});
//--><!]]>
</script>
<script src="/sites/all/themes/macchina_bb/scripts/classie.js"></script>
<script>
    function init() {
        window.addEventListener('scroll', function(e){
            var distanceY = window.pageYOffset || document.documentElement.scrollTop,
                shrinkOn = 300,
                header = document.querySelector("header");
            if (distanceY > shrinkOn) {
                classie.add(header,"smaller");
            } else {
                if (classie.has(header,"smaller")) {
                    classie.remove(header,"smaller");
                }
            }
        });
    }
    window.onload = init();
</script>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

</head>
<body class="html not-front not-logged-in no-sidebars page-content page-content-arduinocc" >
  <div id="skip-link">
    <a href="#main-content" class="element-invisible element-focusable">Skip to main content</a>
  </div>
    <div id="toTop"><span class="glyphicon glyphicon-chevron-up"></span></div><div id="pre-header" class="clearfix"><div class="container"><div id="pre-header-inside" class="clearfix"><div class="row"><div class="col-md-4"><div class="pre-header-area"><div class="region region-pre-header-first"><div id="block-multiblock-2" class="block block-multiblock block-commerce-cart block-commerce-cart-cart-instance clearfix"><h2>cart</h2><div class="content"><div class="cart-empty-block">Your shopping cart is empty.</div></div></div></div></div></div><div class="col-md-4"></div><div class="col-md-4"></div></div></div></div><div class="toggle-control" id = "toggle-control"><a onclick="openNav()" class = "plus"><span class="glyphicon glyphicon-plus"></span></a></div>
<script>
function openNav() {
document.getElementById('pre-header').className += ' opened';
document.getElementById('toggle-control').innerHTML = '<a onclick="closeNav()" class = "minus"><span class="glyphicon glyphicon-minus"></span></a>';
jQuery("#pre-header-inside").animate({"left":"0px"}, "slow");
jQuery(".toggle-control").animate({"left":"300px"}, "slow");
}
function closeNav() {
var active = document.querySelector(".opened");
active.classList.remove("opened");
document.getElementById('toggle-control').innerHTML = '<a onclick="openNav()"><span class="glyphicon glyphicon-plus"></span></a>';
jQuery("#pre-header-inside").animate({"left":"-300px"}, "slow");
jQuery(".toggle-control").animate({"left":"0px"}, "slow");
}
</script>
</div> <header id="header" role="banner" class="clearfix"><div class="container"><div id="header-inside" class="clearfix"><div class="row"><div class="col-md-12"><div id="logo" class="col-md-6"> <a href="/" title="Home" rel="home"> <img src="https://www.macchina.cc/sites/default/files/color/macchina_bb-485d676d/logo.png" alt="Home" /> </a></div><div id="main-navigation" class="col-md-5 col-md-offset-7 col-sm-6 col-sm-offset-6"><div class=""> <nav role="navigation"> </nav></div></div></div></div></div></div></header><div id="page" class="clearfix" onclick="closeNav()"><div id="main-content"><div class="container"><div class="row"> <section class="col-md-12"><div id="main" class="clearfix"><div id="content-wrapper"><h1 class="page-title">Page not found</h1><div class="tabs"></div><div class="region region-content"><div id="block-system-main" class="block block-system clearfix"><div class="content"> The requested page "/content/arduino.cc" could not be found.</div></div></div></div></div> </section></div></div></div><div id="content-middle" class="clearfix"><div class="container"></div></div></div><footer id="footer" class="clearfix"><div class="container"><div id="footer-inside" class="clearfix"><div class="row"><div class="col-md-3"><div class="footer-area"><div class="region region-footer-first"><div id="block-block-12" class="block block-block clearfix"><div class="content"><div style="padding-left: 10px;"><h1>Newsletter</h1><link href="//cdn-images.mailchimp.com/embedcode/slim-081711.css" rel="stylesheet" type="text/css" /><style type="text/css">
<!--#mc_embed_signup{background:#b3e2fc; clear:left; font:14px Helvetica,Arial,sans-serif;  width:300px;}</style><div id="mc_embed_signup"><form action="//rechargecar.us6.list-manage.com/subscribe/post?u=136b2fca7877210ddd553586e&amp;id=6ddcd22273" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" class="validate" target="_blank" novalidate="" style="padding: 0px"><div id="mc_embed_signup_scroll"><input type="email" value="" name="EMAIL" class="email" id="mce-EMAIL" placeholder="email address" required="" /><div style="position: absolute; left: -5000px;"><input type="text" name="b_136b2fca7877210ddd553586e_6ddcd22273" tabindex="-1" value="" /></div><div class="clear"><input type="submit" value="Subscribe" name="subscribe" id="mc-embedded-subscribe" class="button" style="background-color:#ff6600;color:#ffffff" onmouseover="this.style.background='#ffa600'" onmouseout="this.style.background='#ff6600'" /></div></div></form></div><p><br /></p></div></div></div></div></div></div><div class="col-md-3"><div class="footer-area"><div class="region region-footer-second"><div id="block-block-6" class="block block-block clearfix"><div class="content"><div style="padding-left: 10px;"><h1>Contact Us</h1><p>P.O. Box 18701<br />Minneapolis, MN 55418</p><p><b><a href="tel:612-787-2658" style="color:#ff6600">(612) 787-2658</a></b></p><p><b><a href="http://macchina.cc/contact" style="color:#ff6600">Message us</a></b></p><p><br /></p></div></div></div></div></div></div><div class="col-md-3"><div class="footer-area"><div class="region region-footer-third"><div id="block-block-7" class="block block-block clearfix"><div class="content"><div style="padding-left: 10px;"><h1>Community</h1><p>Places worth checking out</p><p><b><a href="http://www.reddit.com/r/carhacking" target="_blank" style="color:#ff6600">Reddit /carhacking</a></b></p><p><b><a href="http://hackaday.com/category/car-hacks/" target="_blank" style="color:#ff6600">Hackaday</a></b></p><p><b><a href="http://opengarages.org/index.php/Main_Page" target="_blank" style="color:#ff6600">Open Garages</a></b></p><p><br /></p></div></div></div></div></div></div><div class="col-md-3"><div class="footer-area"><div class="region region-footer-fourth"><div id="block-block-24" class="block block-block clearfix"><div class="content"><div style="padding-left: 10px;"><h1>Legal Docs</h1><p>Because they made us</p><p><b><a href="https://forum.macchina.cc/t/privacy-policy/6" target="_blank" style="color:#ff6600">Privacy Policy</a></b></p><p><b><a href="https://www.macchina.cc/content/returns-and-refunds-policy" target="_blank" style="color:#ff6600">Return Policy</a></b></p><p><b><a href="https://www.macchina.cc/content/disclaimer" target="_blank" style="color:#ff6600">User Agreement</a></b></p></div></div></div></div></div></div></div></div></div></footer> <footer id="subfooter" class="clearfix"><div class="container"><div id="subfooter-inside" class="clearfix"><div class="row"><div class="col-md-12"><div class="subfooter-area"><div class="region region-footer"><div id="block-block-1" class="block block-block clearfix"><div class="content"><p><font color="white"> Copyright © 2017 Macchina LLC. All rights reserved. </font></p></div></div></div></div></div></div></div></div></footer>  </body>
</html>